﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hangman
{
    public partial class Form1 : Form
    {
        private string secilenKelime;
        private string gizliKelime;
        private int puan = 100;
        private int yanlisTahminSayisi = 0;
        private Bitmap[] hangmanImages = new Bitmap[11];
        private Bitmap[] balonImages = new Bitmap[11];
        private Bitmap[] cicekImages = new Bitmap[11];
        private List<char> yanlisHarfler = new List<char>();
        private Timer oyunSuresiTimer = new Timer();
        private int kalanSure;
        private int baslangicSure;

        private string kategori;
        private string zorluk;
        private string tema;

        private Dictionary<string, List<string>> kategoriKelimeleri;
        private Dictionary<string, List<string>> kategoriIpuculari;
        private string oncekiKelime = "";

        public Form1(string kategori, string zorluk, int sure, string tema)
        {
            InitializeComponent();

            this.kategori = kategori;
            this.zorluk = zorluk;
            this.tema = tema;
            this.kalanSure = sure;
            this.baslangicSure = sure;

            this.Text = $"Kategori: {kategori} | Zorluk: {zorluk} | Tema: {tema} | Süre: {sure} sn";
            this.BackColor = Color.WhiteSmoke;
            this.Font = new Font("Segoe UI", 10);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            oyunSuresiTimer.Interval = 1000;
            oyunSuresiTimer.Tick += OyunSuresiTimer_Tick;

            HazirlaKategoriListeleri();
            HangmanResimleriniYukle();
            BalonResimleriniYukle();
            CicekResimleriniYukle();
            oyunSuresiTimer.Stop(); 

            OyunuBaslat();
        }

        private void OyunuBaslat()
        {
            Random rastgele = new Random();
            List<string> kelimeler = kategoriKelimeleri[kategori]
                .Where(k => ZorlugaUygun(k.Length) && k != oncekiKelime).ToList();

            if (kelimeler.Count == 0)
            {
                MessageBox.Show("Uygun kelime bulunamadı.");
                return;
            }

            secilenKelime = kelimeler[rastgele.Next(kelimeler.Count)];
            oncekiKelime = secilenKelime;
            gizliKelime = string.Join(" ", new string('_', secilenKelime.Length).ToCharArray());
            puan = 100;
            yanlisTahminSayisi = 0;
            kalanSure = baslangicSure;
            yanlisHarfler.Clear();

            lblKelimeUzunlugu.Text = "Kelime Uzunluğu: " + secilenKelime.Length;
            lblGizliKelime.Text = gizliKelime;
            lblPuan.Text = "Puan: " + puan + " P";
            lblYanlisTahminler.Text = "Yanlış Tahminler: ";
            lblSure.Text = "Süre: " + kalanSure + " sn";
            lblSure.ForeColor = Color.Black;

            string temaNormalized = tema.Trim().ToLowerInvariant();
            if (temaNormalized.Contains("balon"))
                pictureBox1.Image = balonImages[0];
            else if (temaNormalized.Contains("çiçek") || temaNormalized.Contains("cicek"))
                pictureBox1.Image = cicekImages[0];
            else
                pictureBox1.Image = hangmanImages[0];



            this.BackColor = Control.DefaultBackColor;
            oyunSuresiTimer.Start();
        }
        private void OyunSuresiTimer_Tick(object sender, EventArgs e)
        {
            kalanSure--;
            lblSure.Text = "Süre: " + kalanSure + " sn";

            if (kalanSure <= 10)
                lblSure.ForeColor = Color.Red;
            else if (kalanSure <= 20)
                lblSure.ForeColor = Color.OrangeRed;
            else if (kalanSure <= 40)
                lblSure.ForeColor = Color.Goldenrod;
            else
                lblSure.ForeColor = Color.DarkGreen;

            if (kalanSure <= 0)
            {
                oyunSuresiTimer.Stop();
                this.BackColor = Color.Red;
                string kaybedilenKelime = secilenKelime; 
                MessageBox.Show("Süre doldu! Kaybettiniz!\nKelime: " + kaybedilenKelime);
                OyunuBaslat();
                
            }
        }

        private void btnTahminEt_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTahmin.Text)) return;
            char harf = txtTahmin.Text.ToLower()[0];
            txtTahmin.Clear();

            if (yanlisHarfler.Contains(harf) || gizliKelime.Contains(harf))
            {
                MessageBox.Show("Bu harfi zaten kullandınız.");
                return;
            }

            if (secilenKelime.Contains(harf))
            {
                var sb = new StringBuilder(gizliKelime);
                for (int i = 0; i < secilenKelime.Length; i++)
                {
                    if (secilenKelime[i] == harf)
                        sb[i * 2] = harf;
                }
                gizliKelime = sb.ToString();
                lblGizliKelime.Text = gizliKelime;

                if (gizliKelime.Replace(" ", "") == secilenKelime)
                {
                    oyunSuresiTimer.Stop();
                    MessageBox.Show("Tebrikler! Kazandınız!");
                    this.BackColor = Color.Green;
                    OyunuBaslat();
                }
            }
            else
            {
                puan -= 10;
                yanlisTahminSayisi++;
                yanlisHarfler.Add(harf);
                lblPuan.Text = "Puan: " + puan + " P";
                lblYanlisTahminler.Text = "Yanlış Tahminler: " + string.Join(", ", yanlisHarfler);

                string temaNormalized = tema.Trim().ToLower();
                if (temaNormalized.Contains("balon") && yanlisTahminSayisi < balonImages.Length)
                    pictureBox1.Image = balonImages[yanlisTahminSayisi];
                else if ((temaNormalized.Contains("çiçek") || temaNormalized.Contains("cicek")) && yanlisTahminSayisi < cicekImages.Length)
                    pictureBox1.Image = cicekImages[yanlisTahminSayisi];
                else if (yanlisTahminSayisi < hangmanImages.Length)
                    pictureBox1.Image = hangmanImages[yanlisTahminSayisi];



                if (puan <= 0 || yanlisTahminSayisi >= 10)
                {
                    oyunSuresiTimer.Stop();
                    MessageBox.Show("Kaybettiniz! Kelime: " + secilenKelime);
                    this.BackColor = Color.Red;
                    OyunuBaslat();
                }
            }
        }

        private void btnIpucu_Click(object sender, EventArgs e)
        {
            int index = kategoriKelimeleri[kategori].IndexOf(secilenKelime);
            if (index >= 0 && index < kategoriIpuculari[kategori].Count)
                MessageBox.Show("İpucu: " + kategoriIpuculari[kategori][index]);
            else
                MessageBox.Show("İpucu bulunamadı.");
        }

        private void btnOyunuBitir_Click(object sender, EventArgs e)
        {
            oyunSuresiTimer.Stop();
            MessageBox.Show("Oyun sonlandırıldı.");
            this.Close();
        }

        private void HangmanResimleriniYukle()
        {
            hangmanImages[0] = Properties.Resources.man_01;
            hangmanImages[1] = Properties.Resources.man_02;
            hangmanImages[2] = Properties.Resources.man_03;
            hangmanImages[3] = Properties.Resources.man_04;
            hangmanImages[4] = Properties.Resources.man_05;
            hangmanImages[5] = Properties.Resources.man_06;
            hangmanImages[6] = Properties.Resources.man_07;
            hangmanImages[7] = Properties.Resources.man_08;
            hangmanImages[8] = Properties.Resources.man_09;
            hangmanImages[9] = Properties.Resources.man_10;
            hangmanImages[10] = Properties.Resources.man_10;
        }

        private void BalonResimleriniYukle()
        {
            balonImages[0] = Properties.Resources.balon0;
            balonImages[1] = Properties.Resources.balon1;
            balonImages[2] = Properties.Resources.balon2;
            balonImages[3] = Properties.Resources.balon3;
            balonImages[4] = Properties.Resources.balon4;
            balonImages[5] = Properties.Resources.balon5;
            balonImages[6] = Properties.Resources.balon6;
            balonImages[7] = Properties.Resources.balon7;
            balonImages[8] = Properties.Resources.balon8;
            balonImages[9] = Properties.Resources.balon9;
            balonImages[10] = Properties.Resources.balon10;
        }

        private void CicekResimleriniYukle()
        {
            cicekImages[0] = Properties.Resources.cicek0;
            cicekImages[1] = Properties.Resources.cicek1;
            cicekImages[2] = Properties.Resources.cicek2;
            cicekImages[3] = Properties.Resources.cicek3;
            cicekImages[4] = Properties.Resources.cicek4;
            cicekImages[5] = Properties.Resources.cicek5;
            cicekImages[6] = Properties.Resources.cicek6;
            cicekImages[7] = Properties.Resources.cicek7;
            cicekImages[8] = Properties.Resources.cicek8;
            cicekImages[9] = Properties.Resources.cicek9;
            cicekImages[10] = Properties.Resources.cicek10;
        }

        private void lblSure_Click(object sender, EventArgs e) { }
        private bool ZorlugaUygun(int uzunluk)
        {
            if (zorluk == "Kolay")
                return uzunluk <= 6;
            else if (zorluk == "Orta")
                return uzunluk > 6 && uzunluk <= 8;
            else if (zorluk == "Zor")
                return uzunluk > 8;
            return true;
        }
        private void HazirlaKategoriListeleri()
        {
            kategoriKelimeleri = new Dictionary<string, List<string>>();
            kategoriIpuculari = new Dictionary<string, List<string>>();

            
            kategoriKelimeleri["Tarih"] = new List<string>
    {
        
        "hitit", "roma", "pers", "lidya", "urartu", "hun", "moğol", "selçuk", "fransız", "spartalı",
        
        "krallık", "rejim", "diktatör", "saray", "divan", "fetih", "cephe", "kuşatma", "elçilik", "halifelik",
        
        "imparator", "medeniyet", "tarihyazım", "milliyetçilik", "muhafazakar", "patrikhane", "monarşiler", "antlaşmalar", "devrimcilik", "modernizm"
    };

            kategoriIpuculari["Tarih"] = new List<string>
    {
        
        "Anadolu uygarlığı", "Antik imparatorluk", "İran kökenli halk", "Parayı icat eden uygarlık", "Doğu Anadolu krallığı", "Orta Asya kavmi",
        "Cengiz Han'ın kurduğu devlet", "Büyük Selçuklu Devleti", "1789 devrimi ülkesi", "Savaşçı Yunan topluluğu",
        
        "Monarşi yönetimi", "Yönetim biçimi", "Baskıcı lider", "Padişahın evi", "Osmanlı'da meclis", "Toprak kazanma", "Cephe hattı",
        "Şehri kuşatma olayı", "Dış ilişkiler görevi", "İslam dünyası liderliği",
       
        "En geniş devlet biçimi", "Kültürel yapı", "Tarih yazımı disiplini", "Ulusalcılık ideolojisi", "Geleneksel muhafaza",
        "Ortodoks merkezleri", "Kraliyet yönetimleri", "Uluslararası sözleşmeler", "Köklü değişim", "Çağdaşlaşma akımı"
    };

           
            kategoriKelimeleri["Coğrafya"] = new List<string>
    {
        
        "dağ", "ova", "göl", "ada", "delta", "çöl", "nehir", "vadi", "yayla", "iklim",
        
        "muson", "plato", "step", "kıta", "lav", "krater", "meridyen", "paralel", "harita", "rüzgar",
        
        "jeotermal", "volkanizma", "tropikal", "jeomorfoloji", "koordinat", "buzullaşma", "hidrosfer", "stratosfer", "atmosfer", "sismograf"
    };

            kategoriIpuculari["Coğrafya"] = new List<string>
    {
        
        "Yükselti şekli", "Düz alan", "Büyük su birikintisi", "Etrafı suyla çevrili kara", "Nehir ağzı birikintisi",
        "Kurak bölge", "Akarsuyun genel adı", "İki dağ arası çöküntü", "Yaygın yüksek alan", "Hava durumu ortalaması",
        
        "Asya'nın rüzgarı", "Yüksek düz alan", "Kurak otlak", "Büyük kara parçası", "Yanardağ sıvısı", "Yanardağ ağzı",
        "Boylam çizgisi", "Enlem çizgisi", "Yeryüzü tasviri", "Hava hareketi",
        
        "Yeraltı sıcak su kaynağı", "Yanardağ oluşumu süreci", "Sıcak nemli kuşak", "Yer şekilleri bilimi",
        "Konum belirleme", "Buz hareketleri", "Su küresi", "Orta atmosfer katı", "Hava katmanı", "Deprem ölçüm cihazı"
    };

            
            kategoriKelimeleri["Matematik"] = new List<string>
    {
       
        "sayı", "rakam", "çarpma", "bölme", "kesir", "eşit", "açı", "çizgi", "kare", "üçgen",
        
        "fonksiyon", "türev", "matris", "grafik", "çözüm", "çarpan", "mantık", "kümeler", "koordinat", "geometri",
        
        "trigonometri", "logaritma", "integral", "analiz", "faktöriyel", "kompleks", "aritmetik", "eşitsizlik", "standart", "diferansiyel"
    };

            kategoriIpuculari["Matematik"] = new List<string>
    {
        
        "Miktar kavramı", "Basit sayı simgesi", "Çoğaltma işlemi", "Paylaştırma işlemi", "Parçalı sayı", "İki taraf eşittir", "İki kenar arası açıklık",
        "Düz iz", "Dört kenarlı şekil", "Üç kenarlı şekil",
        
        "Girdi-çıktı ilişkisi", "Değişim oranı", "Dizi tablosu", "Veri görseli", "Sonuca ulaşma", "Çarpımın bileşeni", "Akıl yürütme yöntemi",
        "Öğe grubu", "Nokta belirleme sistemi", "Şekiller bilimi",
        
        "Açı oranları", "Üstel işlem", "Alan hesaplaması", "İnceleme yöntemi", "Çarpım sonucu", "Karmaşık sayı", "Dört işlem temeli",
        "Denklem karşılaştırması", "Ortalama ölçüm", "Türev konusu"
    };

            
            kategoriKelimeleri["Genel Kültür"] = new List<string>
    {
        
        "sanat", "spor", "müzik", "film", "şiir", "hukuk", "kitap", "gazete", "internet", "opera",
        
        "astronomi", "felsefe", "psikoloji", "arkeoloji", "biyoloji", "teknoloji", "bilgisayar", "tiyatro", "yazar", "şair",
        
        "entelektüel", "modernizm", "postmodern", "sekülerizm", "toplumculuk", "sürrealizm", "aydınlanma", "psikanaliz", "materyalizm", "globalleşme"
    };

            kategoriIpuculari["Genel Kültür"] = new List<string>
    {
        
        "Estetik üretim", "Fiziksel aktivite", "Melodi sanatı", "Görüntü sanatı", "Nazım biçimi",
        "Yasa sistemi", "Okunabilir eser", "Basılı haber kaynağı", "Bilgi ağı", "Müzikal sahne",
       
        "Uzay bilimi", "Düşünce bilimi", "Zihin çalışması", "Kazı bilimi", "Canlılar bilimi", "Modern araç", "Sayısal sistem", "Sahne sanatı", "Kitap yazarı", "Dize yazarı",
        
        "Zihinsel birikim", "Çağdaşlık akımı", "Yeni dönem estetiği", "Laiklik anlayışı", "Toplum merkezli düşünce", "Gerçeküstücülük", "Akıl çağı", "Zihin çözümleme", "Madde temelli felsefe", "Dünya çapında etkileşim"
    };

            
            kategoriKelimeleri["Karma"] = kategoriKelimeleri.Values.SelectMany(l => l).ToList();
            kategoriIpuculari["Karma"] = kategoriIpuculari.Values.SelectMany(l => l).ToList();
        }


    }
}
