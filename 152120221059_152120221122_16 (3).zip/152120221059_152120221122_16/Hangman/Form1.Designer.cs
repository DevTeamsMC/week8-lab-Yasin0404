﻿namespace Hangman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSure = new System.Windows.Forms.Label();
            this.lblKelimeUzunlugu = new System.Windows.Forms.Label();
            this.lblGizliKelime = new System.Windows.Forms.Label();
            this.txtTahmin = new System.Windows.Forms.TextBox();
            this.btnTahminEt = new System.Windows.Forms.Button();
            this.lblPuan = new System.Windows.Forms.Label();
            this.lblYanlisTahminler = new System.Windows.Forms.Label();
            this.btnOyunuBitir = new System.Windows.Forms.Button();
            this.btnIpucu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSure
            // 
            this.lblSure.AutoSize = true;
            this.lblSure.Location = new System.Drawing.Point(35, 355);
            this.lblSure.Name = "lblSure";
            this.lblSure.Size = new System.Drawing.Size(72, 16);
            this.lblSure.TabIndex = 11;
            this.lblSure.Text = "Süre: 60 sn";
            this.lblSure.Click += new System.EventHandler(this.lblSure_Click);
            // 
            // lblKelimeUzunlugu
            // 
            this.lblKelimeUzunlugu.AutoSize = true;
            this.lblKelimeUzunlugu.Location = new System.Drawing.Point(35, 179);
            this.lblKelimeUzunlugu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKelimeUzunlugu.Name = "lblKelimeUzunlugu";
            this.lblKelimeUzunlugu.Size = new System.Drawing.Size(112, 16);
            this.lblKelimeUzunlugu.TabIndex = 1;
            this.lblKelimeUzunlugu.Text = "Kelime Uzunluğu: ";
            // 
            // lblGizliKelime
            // 
            this.lblGizliKelime.AutoSize = true;
            this.lblGizliKelime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGizliKelime.Location = new System.Drawing.Point(33, 98);
            this.lblGizliKelime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGizliKelime.Name = "lblGizliKelime";
            this.lblGizliKelime.Size = new System.Drawing.Size(52, 25);
            this.lblGizliKelime.TabIndex = 2;
            this.lblGizliKelime.Text = "-----";
            // 
            // txtTahmin
            // 
            this.txtTahmin.Location = new System.Drawing.Point(38, 286);
            this.txtTahmin.Margin = new System.Windows.Forms.Padding(4);
            this.txtTahmin.Name = "txtTahmin";
            this.txtTahmin.Size = new System.Drawing.Size(65, 22);
            this.txtTahmin.TabIndex = 3;
            // 
            // btnTahminEt
            // 
            this.btnTahminEt.BackColor = System.Drawing.Color.DarkOrange;
            this.btnTahminEt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTahminEt.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTahminEt.Location = new System.Drawing.Point(127, 286);
            this.btnTahminEt.Margin = new System.Windows.Forms.Padding(4);
            this.btnTahminEt.Name = "btnTahminEt";
            this.btnTahminEt.Size = new System.Drawing.Size(105, 43);
            this.btnTahminEt.TabIndex = 4;
            this.btnTahminEt.Text = "Tahmin Et";
            this.btnTahminEt.UseVisualStyleBackColor = false;
            this.btnTahminEt.Click += new System.EventHandler(this.btnTahminEt_Click);
            // 
            // lblPuan
            // 
            this.lblPuan.AutoSize = true;
            this.lblPuan.Location = new System.Drawing.Point(41, 248);
            this.lblPuan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(44, 16);
            this.lblPuan.TabIndex = 5;
            this.lblPuan.Text = "Puan: ";
            // 
            // lblYanlisTahminler
            // 
            this.lblYanlisTahminler.AutoSize = true;
            this.lblYanlisTahminler.Location = new System.Drawing.Point(35, 213);
            this.lblYanlisTahminler.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYanlisTahminler.Name = "lblYanlisTahminler";
            this.lblYanlisTahminler.Size = new System.Drawing.Size(113, 16);
            this.lblYanlisTahminler.TabIndex = 6;
            this.lblYanlisTahminler.Text = "Yanlış Tahminler: ";
            // 
            // btnOyunuBitir
            // 
            this.btnOyunuBitir.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnOyunuBitir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOyunuBitir.Location = new System.Drawing.Point(260, 286);
            this.btnOyunuBitir.Margin = new System.Windows.Forms.Padding(4);
            this.btnOyunuBitir.Name = "btnOyunuBitir";
            this.btnOyunuBitir.Size = new System.Drawing.Size(120, 43);
            this.btnOyunuBitir.TabIndex = 7;
            this.btnOyunuBitir.Text = "Oyunu Bitir";
            this.btnOyunuBitir.UseVisualStyleBackColor = false;
            this.btnOyunuBitir.Click += new System.EventHandler(this.btnOyunuBitir_Click);
            // 
            // btnIpucu
            // 
            this.btnIpucu.BackColor = System.Drawing.Color.SpringGreen;
            this.btnIpucu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIpucu.Location = new System.Drawing.Point(169, 137);
            this.btnIpucu.Margin = new System.Windows.Forms.Padding(4);
            this.btnIpucu.Name = "btnIpucu";
            this.btnIpucu.Size = new System.Drawing.Size(100, 28);
            this.btnIpucu.TabIndex = 8;
            this.btnIpucu.Text = "İpucu";
            this.btnIpucu.UseVisualStyleBackColor = false;
            this.btnIpucu.Click += new System.EventHandler(this.btnIpucu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Font = new System.Drawing.Font("Engravers MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(442, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "HANGMAN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hangman.Properties.Resources.man_01;
            this.pictureBox1.Location = new System.Drawing.Point(419, 85);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(571, 416);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Hangman.Properties.Resources.cover2;
            this.pictureBox2.Location = new System.Drawing.Point(-1, -3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1096, 543);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 539);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIpucu);
            this.Controls.Add(this.btnOyunuBitir);
            this.Controls.Add(this.lblYanlisTahminler);
            this.Controls.Add(this.lblPuan);
            this.Controls.Add(this.btnTahminEt);
            this.Controls.Add(this.txtTahmin);
            this.Controls.Add(this.lblGizliKelime);
            this.Controls.Add(this.lblKelimeUzunlugu);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblSure);
            this.Controls.Add(this.pictureBox2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Adam Asmaca Oyunu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblKelimeUzunlugu;
        private System.Windows.Forms.Label lblGizliKelime;
        private System.Windows.Forms.TextBox txtTahmin;
        private System.Windows.Forms.Button btnTahminEt;
        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Label lblYanlisTahminler;
        private System.Windows.Forms.Button btnOyunuBitir;
        private System.Windows.Forms.Button btnIpucu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}