﻿namespace Hangman.Properties
{
    partial class OyunEkrani
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxKategori;
        private System.Windows.Forms.ComboBox comboBoxZorluk;
        private System.Windows.Forms.ComboBox comboBoxTema;
        private System.Windows.Forms.NumericUpDown numericUpDownSure;
        private System.Windows.Forms.Label labelKategori;
        private System.Windows.Forms.Label labelZorluk;
        private System.Windows.Forms.Label labelTema;
        private System.Windows.Forms.Label labelSure;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxKategori = new System.Windows.Forms.ComboBox();
            this.comboBoxZorluk = new System.Windows.Forms.ComboBox();
            this.comboBoxTema = new System.Windows.Forms.ComboBox();
            this.numericUpDownSure = new System.Windows.Forms.NumericUpDown();
            this.labelKategori = new System.Windows.Forms.Label();
            this.labelZorluk = new System.Windows.Forms.Label();
            this.labelTema = new System.Windows.Forms.Label();
            this.labelSure = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSure)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSalmon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Engravers MT", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(490, 512);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "BAŞLA";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hangman.Properties.Resources.cover;
            this.pictureBox1.Location = new System.Drawing.Point(-14, -38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1168, 685);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(461, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 50);
            this.label1.TabIndex = 2;
            this.label1.Text = "HANGMAN";
            // 
            // comboBoxKategori
            // 
            this.comboBoxKategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxKategori.Items.AddRange(new object[] {
            "Tarih",
            "Coğrafya",
            "Matematik",
            "Genel Kültür",
            "Karma"});
            this.comboBoxKategori.Location = new System.Drawing.Point(50, 50);
            this.comboBoxKategori.Name = "comboBoxKategori";
            this.comboBoxKategori.Size = new System.Drawing.Size(121, 24);
            this.comboBoxKategori.TabIndex = 3;
            // 
            // comboBoxZorluk
            // 
            this.comboBoxZorluk.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxZorluk.Items.AddRange(new object[] {
            "Kolay",
            "Orta",
            "Zor"});
            this.comboBoxZorluk.Location = new System.Drawing.Point(50, 100);
            this.comboBoxZorluk.Name = "comboBoxZorluk";
            this.comboBoxZorluk.Size = new System.Drawing.Size(121, 24);
            this.comboBoxZorluk.TabIndex = 4;
            // 
            // comboBoxTema
            // 
            this.comboBoxTema.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxTema.Items.AddRange(new object[] {
            "Adam As",
            "Balon Patlat",
            "Çiçek Kopar"});
            this.comboBoxTema.Location = new System.Drawing.Point(50, 150);
            this.comboBoxTema.Name = "comboBoxTema";
            this.comboBoxTema.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTema.TabIndex = 5;
            // 
            // numericUpDownSure
            // 
            this.numericUpDownSure.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericUpDownSure.Location = new System.Drawing.Point(50, 200);
            this.numericUpDownSure.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numericUpDownSure.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownSure.Name = "numericUpDownSure";
            this.numericUpDownSure.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownSure.TabIndex = 6;
            this.numericUpDownSure.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // labelKategori
            // 
            this.labelKategori.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelKategori.Location = new System.Drawing.Point(200, 50);
            this.labelKategori.Name = "labelKategori";
            this.labelKategori.Size = new System.Drawing.Size(100, 23);
            this.labelKategori.TabIndex = 7;
            this.labelKategori.Text = "Kategori:";
            // 
            // labelZorluk
            // 
            this.labelZorluk.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelZorluk.Location = new System.Drawing.Point(200, 100);
            this.labelZorluk.Name = "labelZorluk";
            this.labelZorluk.Size = new System.Drawing.Size(100, 23);
            this.labelZorluk.TabIndex = 8;
            this.labelZorluk.Text = "Zorluk:";
            // 
            // labelTema
            // 
            this.labelTema.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelTema.Location = new System.Drawing.Point(200, 150);
            this.labelTema.Name = "labelTema";
            this.labelTema.Size = new System.Drawing.Size(100, 23);
            this.labelTema.TabIndex = 9;
            this.labelTema.Text = "Tema:";
            // 
            // labelSure
            // 
            this.labelSure.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelSure.Location = new System.Drawing.Point(200, 200);
            this.labelSure.Name = "labelSure";
            this.labelSure.Size = new System.Drawing.Size(100, 23);
            this.labelSure.TabIndex = 10;
            this.labelSure.Text = "Süre (sn):";
            // 
            // OyunEkrani
            // 
            this.ClientSize = new System.Drawing.Size(1142, 683);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxKategori);
            this.Controls.Add(this.comboBoxZorluk);
            this.Controls.Add(this.comboBoxTema);
            this.Controls.Add(this.numericUpDownSure);
            this.Controls.Add(this.labelKategori);
            this.Controls.Add(this.labelZorluk);
            this.Controls.Add(this.labelTema);
            this.Controls.Add(this.labelSure);
            this.Controls.Add(this.pictureBox1);
            this.Name = "OyunEkrani";
            this.Text = "OyunEkrani";
            this.Load += new System.EventHandler(this.OyunEkrani_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSure)).EndInit();
            this.ResumeLayout(false);

        }
    }
}
