﻿using System;
using System.Windows.Forms;

namespace Hangman.Properties
{
    public partial class OyunEkrani : Form
    {
        public OyunEkrani()
        {
            InitializeComponent();
            comboBoxKategori.SelectedIndex = 0;
            comboBoxZorluk.SelectedIndex = 0;
            comboBoxTema.SelectedIndex = 0;
            numericUpDownSure.Value = 60;
        }

        private void OyunEkrani_Load(object sender, EventArgs e)
        {
            // Form yüklendiğinde yapılacak işlemler (gerekirse)
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kategori = comboBoxKategori.SelectedItem.ToString();
            string zorluk = comboBoxZorluk.SelectedItem.ToString();
            int sure = (int)numericUpDownSure.Value;
            string tema = comboBoxTema.SelectedItem.ToString();

            Form1 oyunFormu = new Form1(kategori, zorluk, sure, tema);
            this.Hide();
            oyunFormu.ShowDialog();
            this.Show();
        }
    }
}
